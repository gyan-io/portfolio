# Portfolio Journal

An interactive journal-style portfolio for Paa Kwesi Gyan Turkson. One self-contained HTML file: no build step, no dependencies.

Flip pages by dragging either page edge, tapping a dashed-trail target, dragging the ribbon, or using the arrow keys.

## Deploy on GitHub Pages

1. Create a repo and push these files to `main`.
2. Settings > Pages > Source: "Deploy from a branch", Branch: `main`, Folder: `/ (root)`.
3. Wait about a minute, then open the URL Pages shows.

`.nojekyll` is included so Pages serves files as-is.
